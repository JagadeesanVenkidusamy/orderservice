package org.example;

import java.util.Arrays;

public class ProductArray {
    public static int[] product(int[] nums) {
        int n = nums.length;
        int[] answer = new int[n];
        answer[0] = 1;
        for (int i = 1; i<n; i++) {
            answer[i] = answer[i-1] * nums[i-1];
        }

        int sProduct = 1;
        for(int i = n-1; i>=0; i--) {
            answer[i] = answer[i] * sProduct;
            sProduct *= nums[i];
        }
        return answer;
    }

    public static void main(String[] args) {
        int[] nums = {1,2,3,4};
        int[] result = product(nums);
        System.out.println("output 1 is: "+Arrays.toString(result));

        int[] nums2 = {-1, 1, 0, -3, 3};
        int[] result2 = product(nums2);
        System.out.println("output 2 is: "+Arrays.toString(result2));
    }
}
