package org.example;

import java.util.Stack;

public class RemoveStars {

    public static <stringBuilder> String removeStars(String str) {

        Stack<Character> stack = new Stack<>();
        for (char ch : str.toCharArray()) {
            if(ch == '*') {
                if(!stack.isEmpty()){
                    stack.pop();
                }
            } else {
                stack.push(ch);
            }
        }
        StringBuilder result = new StringBuilder();
        while(!stack.isEmpty()){
            result.append(stack.pop());
        }
        return result.reverse().toString();
    }

    public static void main(String[] args) {
        String s1 = "leet**cod*e";
        System.out.println("Output is: " +removeStars(s1));

        String s2 = "erase*****";
        System.out.println("Output is: " +removeStars(s2));
    }

}
