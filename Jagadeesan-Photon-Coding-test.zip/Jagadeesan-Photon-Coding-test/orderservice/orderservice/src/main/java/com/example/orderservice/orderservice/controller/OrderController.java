package com.example.orderservice.orderservice.controller;

import com.example.orderservice.orderservice.model.Order;
import com.example.orderservice.orderservice.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/orders")
@Slf4j
public class OrderController {

    private final OrderService orderService;
    private final RestTemplate restTemplate;

    public OrderController(OrderService orderService, RestTemplate restTemplate) {
        this.orderService = orderService;
        this.restTemplate = restTemplate;
    }

    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        try {
            for(Long productId: order.getProducts()) {
                ResponseEntity<?> response = restTemplate.getForEntity("http://localhost:8080/products/" + productId, Order.class);
                if(response.getStatusCode().is2xxSuccessful()) {
                    log.info("failed to fetch the product: " + productId);
                    return ResponseEntity.badRequest().body(null);
                }
            }

            Order createOrder = orderService.createOrder(order);
            log.info("createOrder: " + createOrder);
            return ResponseEntity.ok(createOrder);
        } catch (Exception ex){
            log.info("Error creating Order: " + ex.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
}
