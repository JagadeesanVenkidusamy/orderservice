package com.example.orderservice.orderservice.service;

import com.example.orderservice.orderservice.model.Order;
import com.example.orderservice.orderservice.repository.OrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;

@Service
public class OrderService {

    private OrderRepository orderRepository;
    private final RestTemplate restTemplate;

    public OrderService(OrderRepository orderRepository, RestTemplate restTemplate) {
        this.orderRepository = orderRepository;
        this.restTemplate = restTemplate;
    }

    public Order createOrder(Order orderEntity) {
        orderEntity.setOrderDate(LocalDate.now());
        return orderRepository.save(orderEntity);
    }
}
